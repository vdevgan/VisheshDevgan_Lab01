﻿using System;
using Microsoft.EntityFrameworkCore;

namespace VisheshDevgan_Lab01.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> i) : base(i) { }

        public DbSet<ParticipantsResponse> response { get; set; }
    }
}

