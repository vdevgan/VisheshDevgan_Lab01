﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VisheshDevgan_Lab01.Models;
using System.Linq;

namespace VisheshDevgan_Lab01.Models
{
    public class EFRepository : Repository
    {
        private ApplicationDbContext context;

        public EFRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<ParticipantsResponse> Responses => context.response;

        public void AddResponse(ParticipantsResponse response)
        {
            if (response.Id == 0)
            {
                context.response.Add(response);
            }
            else
            {
                ParticipantsResponse entry = context.response.FirstOrDefault(p => p.Id == response.Id);
                if (entry != null)
                {
                    entry.Name = response.Name;
                    entry.Email = response.Email;
                    entry.Phone = response.Phone;
                    entry.WillAttend = response.WillAttend;
                }
            }
            context.SaveChanges();
        }

        public ParticipantsResponse DeleteResponse(int reponseId)
        {
            ParticipantsResponse dbEntry = context.responses.FirstOrDefault(p => p.Id == reponseId);

            if (dbEntry != null)
            {
                context.responses.Remove(dbEntry);
                context.SaveChanges();
            }

            return dbEntry;
        }







    }
}
