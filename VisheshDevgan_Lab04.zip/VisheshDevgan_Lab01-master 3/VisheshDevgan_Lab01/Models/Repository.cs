﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VisheshDevgan_Lab01.Models
{
    public interface Repository
    {
        private static List<ParticipantsResponse> responses = new List<ParticipantsResponse>();

        public IQueryable<ParticipantsResponse> Responses { get; }

        void AddResponse(ParticipantsResponse response);

        ParticipantsResponse DeleteResponse(int id);
     }
}
