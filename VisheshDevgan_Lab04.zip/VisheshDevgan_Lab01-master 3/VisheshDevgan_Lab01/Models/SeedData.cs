﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using VisheshDevgan_Lab01.Models;
using System.Linq;


namespace VisheshDevgan_Lab01.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder i)
        {
            ApplicationDbContext context = i.ApplicationServices.GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.response.Any())
            {
                context.response.AddRange(

                new ParticipantsResponse
                {
                    Name = "Johnny",
                    Email = "j@gmail.com",
                    Phone = "4373434343",
                    WillAttend = false
                },

                new ParticipantsResponse
                {
                    Name = "Tim Hortons",
                    Email = "tim@gmail.com",
                    Phone = "43745454545",
                    WillAttend = false
                },

                 new ParticipantsResponse
                 {
                     Name = "Suzzie lu",
                     Email = "Slu@gmail.com",
                     Phone = "4370909876",
                     WillAttend = false
                 },

                new ParticipantsResponse
                {
                    Name = "Rajesh Kumar",
                    Email = "raj@hotmail.com",
                    Phone = "4379876523",
                    WillAttend = false
                },

                new ParticipantsResponse
                {
                    Name = "Xiang ye",
                    Email = "xiang@gmail.com",
                    Phone = "4371298657",
                    WillAttend = false
                },

                 new ParticipantsResponse
                 {
                     Name = "Lucas Dobry",
                     Email = "Lucas@yahoo.com",
                     Phone = "4370936784",
                     WillAttend = false
                 },

                new ParticipantsResponse
                {
                    Name = "Priti Kaur",
                    Email = "PKaur@gmail.com",
                    Phone = "4378787876",
                    WillAttend = false
                },

                new ParticipantsResponse
                {
                    Name = "Tanya Ramanoff",
                    Email = "Tanya@yahoomail.ca",
                    Phone = "4371295453",
                    WillAttend = false
                },

                 new ParticipantsResponse
                 {
                     Name = "Paul Rogan",
                     Email = "Rogan@gamil.com",
                     Phone = "4379876000",
                     WillAttend = false
                 }

                 );

                context.SaveChanges();
            }
        }
    }
}
