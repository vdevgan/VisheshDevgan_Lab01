﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using VisheshDevgan_Lab01.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace VisheshDevgan_Lab01.Controllers
{
    public class HomeController : Controller
    {
        ApplicationDbContext context;

        public HomeController(ApplicationDbContext context)
        {
            this.context = context;
        }


        public ViewResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour;
            return View("View");
        }


        [HttpGet]
        public ViewResult BursaryForm()
        {
            return View();
        }


        [HttpPost]
        public ViewResult RsvpForm(ParticipantsResponse response)
        {
            EFRepository repository = new EFRepository(context);
            if (ModelState.IsValid)
            {
                repository.AddResponse(response);
                return View("Thanks", response);
            }
            else
            {
                //There is validation error in form
                return View();
            }
        }


        public ViewResult ShowResponses()
        {
            EFRepository repo = new EFRepository(context);
            return View(repo.Responses.Where(r => r.WillAttend == false));
        }

        // Edit Action
        public ViewResult Edit(int responseId)
        {
            EFRepository repo = new EFRepository(context);
            return View(repo.Responses.FirstOrDefault(p => p.Id == responseId));
        }

        [Authorize]
        [HttpPost]
        public IActionResult Edit(ParticipantsResponse response)
        {
            EFRepository repo = new EFRepository(context);
            if (ModelState.IsValid)
            {
                repo.AddResponse(response);
                TempData["message"] = $"{response.Name} saved";
                return RedirectToAction("Index");
            }
            else
            {
                // There's something wrong with data values
                return View(response);
            }
        }

        [HttpPost]
        public IActionResult Delete(int responseId)
        {
            EFRepository repo = new EFRepository(context);
            ParticipantsResponse deletedProduct = repo.DeleteResponse(responseId);
            if (deletedProduct != null)
            {
                TempData["message"] = $"{deletedProduct.Name} deleted";
            }
            return RedirectToAction("ShowResponses");
        }
















        public ViewResult Privacy()
        {
            return View();
        }
    }
}